#
# Name
# Date
# Bug Collector Programming Project
# COSC 2409 DNT
#
# Initialize variables for bugs and total number of bugs collected.

# Get number of bugs collected each day using a for loop.

# Display the total number of bugs collected.
