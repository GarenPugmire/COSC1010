# Instructions  

Assume a file containing a series of integers is named `numbers.txt` and exists on the computer's disk (already uploaded to the Replit environment). Write a program that displays all of the numbers in the file.

Review the [File Display](https://mediaplayer.pearsoncmg.com/assets/_video.true/File_Display) VideoNotes. You will see the output you should have for this programming challenge as well as the code.