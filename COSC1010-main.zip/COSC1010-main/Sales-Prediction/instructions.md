# Instructions  

A company has determined that its annual profit is typically 23 percent of total sales. Write a program that asks the user to enter the projected amount of total sales, then displays the profit that will be made from that amount. Hint: Use the value 0.23 to represent 23 percent.

Review [The Sales Prediction Problem](https://mediaplayer.pearsoncmg.com/assets/_video.true/The_Sales_Prediction_Problem) VideoNotes. You will see the output you should have for this programming challenge as well as the code.