#
# Name
# Date
# Sales Prediction Programming Project
# COSC 2409 DNT
#

# Variables to hold the sales total and the profit

# Get the amount of projected sales.

# Calculate the projected profit.

# Print the projected profit.
