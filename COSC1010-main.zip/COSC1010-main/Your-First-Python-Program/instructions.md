# Instructions  

Ready for your first Python program?! Let's use the the tried and true Hello Wold program as our first program. All you need to do is enter the following (after filling in your name and date in the comments):
```python
# This is my first Python program.

print("Hello World!")
```
Ready! Set! Go!!