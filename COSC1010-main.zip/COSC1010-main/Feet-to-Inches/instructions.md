# Instructions  

One foot equals 12 inches. Write a function named feet_to_inches that accepts a number of feet as an argument and returns the number of inches in that many feet. Use the function in a program that prompts the user to enter a number of feet then displays the number of inches in that many feet.

  Review [The Feet to Inches Problem](https://mediaplayer.pearsoncmg.com/assets/_video.true/The_Feet_To_Inches_Problem) VideoNotes. You will see the output you should have for this programming challenge as well as the code.