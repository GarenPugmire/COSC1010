# Instructions  

Write a program that will ask the user to enter the amount of a purchase. The program should then compute the state and county sales tax. Assume the state sales tax is 5 percent and the county sales tax is 2.5 percent. 
The program should display the following:
* The amount of the purchase
* The state sales tax
* The county sales tax
* The total sales tax
* The total of the sale (which is the sum of the amount of purchase plus the total sales tax)

__Hint: Use the value 0.025 to represent 2.5 percent, and 0.05 to represent 5 percent.__