# Instructions  
The area of a rectangle is the rectangle’s length times its width. Write a program that asks for the length and width of two rectangles. The program should tell the user which rectangle has the greater area, or if the areas are the same.

Review [The Areas of Rectangles Problem](https://mediaplayer.pearsoncmg.com/assets/_video.true/The_Areas_of_Rectangles_Problem) VideoNotes. You will see the output you should have for this programming challenge as well as the code.